const mongoose = require('mongoose');

const rideSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  captain: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Captain'
  },
  pickup: {
    type: String,
    required: true
  },
  destination: {
    type: String,
    required: true
  },
  fare: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'ongoing', 'completed', 'cancelled'],
    default: 'pending'
  },
  duration: {
    type: Number
  },
  distance: {
    type: Number
  },
  vehicleType: {
    type: String,
    required: true,
    enum: ['auto', 'car', 'moto']
  },
  otp: {
    type: String,
    required: true
  }
}, { timestamps: true });

module.exports = mongoose.model('Ride', rideSchema);
